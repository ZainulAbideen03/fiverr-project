<?php
if(!isset($_POST['submit']))
{
	//This page should not be accessed directly. Need to submit the form.
}
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$serviceType = $_POST['serviceType'];
$orgType = $_POST['orgType'];
$orgName = $_POST['orgName'];
$position = $_POST['position'];
$visitor_email = $_POST['visitor_email'];
$message = $_POST['message'];
$address1 = $_POST['address1'];
$address2 = $_POST['address2'];
$city = $_POST['city'];
$zip = $_POST['zip'];
$conNumber = $_POST['conNumber'];
$product = $_POST['product'];
$quantity = $_POST['quantity'];
$destination = $_POST['destination'];


//Validate first
if(empty($fname)||empty($lname)||empty($visitor_email))
{
    echo "Name and email are mandatory!";
    exit;
}

if(IsInjected($visitor_email))
{
    echo "Bad email value!";
    exit;
}

$email_from = $visitor_email;//<== update the email address
$email_subject = "New Buyer Form submission";
$email_body = "You have received a new message from the user $fname $lname.\n".
    "Service Type: $serviceType \n
    Organization Type: $orgType \n
    Organization Name: $orgName \n
    Position: $position \n
	Product: $product \n
	Quantity: $quantity \n
	Destination: $destination \n
    Address Line 1: $address1 \n
    Address Line 2: $address2 \n
    City/Town: $city \n
    Zip: $zip \n
    Contact Number: $conNumber \n
    Here is the message: $message \n".

$to = "nabeelkhatri12@gmail.com";//<== update the email address
$headers = "From: $email_from \r\n";
$headers .= "Reply-To: $visitor_email \r\n";
//Send the email!
mail($to,$email_subject,$email_body,$headers);
header("Location:https://nabeelkhatri.000webhostapp.com/buyer_form.html");

// Function to validate against any email injection attempts
function IsInjected($str)
{
  $injections = array('(\n+)',
              '(\r+)',
              '(\t+)',
              '(%0A+)',
              '(%0D+)',
              '(%08+)',
              '(%09+)'
              );
  $inject = join('|', $injections);
  $inject = "/$inject/i";
  if(preg_match($inject,$str))
    {
    return true;
  }
  else
    {
    return false;
  }
}
?>
